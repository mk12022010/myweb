#This is a comment
# Assignment operator
x = 5
y <- 6
7 -> z

# Print the values of the objects (x, y, z)
x
y
z

x+y
# X+y will not work, because R is case sensitive
y*z

# R is not space sensitive
y     *       z

z - x

z/x
# Modulus operator (remainder)
z%/%x
z%%x

ceiling(1.4)
floor(1.4)
floor(1.9)
round(1.4)
round(1.5)

round(1.62548)
round(1.62548, 2)

round(z/y, digits = 3)
round(z/y, 3)
round(3, z/y)
round(digits = 3, z/y)

x = 5
x

x^2
x^3

sqrt(9)

degree = 100
fahrenheit = degree*9/5 + 32
fahrenheit

(fahrenheit = degree*9/5 + 32)

# sequence, random number generate

1:5
12:18

seq()
seq(20, 60, 3)
seq(20, 60, length.out = 10)

rep(2, 4)
#rep(m, 5)
rep('m', 5)

# sample
sample(1:32, 32, replace = FALSE)

set.seed(10)
sample(1:32, 32, replace = FALSE)

Treatment = rep(c('T1', 'T2', 'T3'), 4)
Replication = c(rep('R1', 3), rep('R2', 3), rep('R3', 3), rep('R4', 3))
Serial = 1:12

dt = data.frame(Serial, Treatment, Replication)

dt

write.csv(dt, 'kamrul.csv', row.names = FALSE)

# reading a dataset
df = read.csv('kamrul.csv')
summary(df)

df$Treatment = as.factor(df$Treatment)
df$Replication = as.factor(df$Replication)
df$Knowledge = as.factor(df$Knowledge)

summary(df)
